# Pyarmor 8.5.8 (trial), 000000, 2024-05-16T03:59:53.150619
from .pyarmor_runtime import __pyarmor__
